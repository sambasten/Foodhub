<?php 
	define("MYSQLSERVER","localhost"); 
	define("MYSQLDB","mysqldb"); 
	define("MYSQLUSER","username"); 
	define("MYSQLPASSWORD","password"); 
?>